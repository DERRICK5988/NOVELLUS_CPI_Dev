/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.text.DecimalFormat;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import groovy.json.JsonSlurper 
def Message processData(Message message) {
    //Body
    def body = message.getBody();
    Reader oReader = message.getBody(Reader)

    // Define XML parser and builder
    def oRoot = new JsonSlurper().parse(oReader)
    def vWriter = new StringWriter()
    def vBuilder = new MarkupBuilder(vWriter)
    def oJsonSlurper = new JsonSlurper()
    DecimalFormat df = new DecimalFormat("0.0");
    def oValueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    df.setMaximumFractionDigits(1);
    vBuilder.'p1:WorkforcePersonMasterDataReplicationRequest_sync'('xmlns:p1': 'http://sap.com/xi/PASEIN'){
        
         oRoot.each{ employee -> 
                if(employee.Tenant.size() > 0 ){
                    def manager = employee.Manager.findAll{ element ->
                    return element.DateTo == null
                }[0]
                'WorkforcePersonMasterData'{
                        'PersonUUID'(employee.Id)
                        'PersonExternalID'(employee.Id)
                        'PersonalInformation'{
                                'FirstName'(employee.Firstname)
                                'LastName'(employee.Lastname)
                                'PersonFullName'(employee.Firstname + " " + employee.Lastname)
                                'GenderCode'("0")
                            }
                        'WorkPlaceInformation'{
                            'EmailAddress'(employee.MailAddress)
                        }
                        'WorkAgreementInformation'{
                        'PersonWorkAgreementUUID'(employee.Id)
                        'PersonWorkAgreementExternalID'(employee.Id)
                        'PersonWorkAgreementType'("1")
                        def oEmployeeOrgList = []
                        
                        // oEmployeeOrgList.push(oJsonSlurper.parseText('{'+
                        //     '"StartDate": "' + employee.prevOrgEntryDate + '",' +
                        //     '"CompanyCode": "' + oValueMapApi.getMappedValue('Rexx', 'organisation', employee.prevOrg, 'S4', 'companycode') + '",' +
                        //     '"TerminationDate": "' + employee.entryDate + '"}'))
                        
                        // oEmployeeOrgList.push(oJsonSlurper.parseText('{'+
                        //     '"StartDate": "' + employee.entryDate + '",' +
                        //     '"CompanyCode": "' +  oValueMapApi.getMappedValue('Rexx', 'organisation', employee.organisation, 'S4', 'companycode') + '",' +
                        //     '"TerminationDate": "' + employee.nextOrgEntryDate + '"}'))
                        
                            
                        // oEmployeeOrgList.push(oJsonSlurper.parseText('{'+
                        //     '"StartDate": "' + employee.nextOrgEntryDate + '",' +
                        //     '"CompanyCode": "' + oValueMapApi.getMappedValue('Rexx', 'organisation', employee.nextOrg, 'S4', 'companycode') + '",' +
                        //     '"TerminationDate": "' + employee.terminationDate + '"}'))
                        def worktimeArray = [];
                                     employee.WorkingTime.each{ WorkingTime ->
                                         worktimeArray << WorkingTime.Duration.replace (":", ".").substring(0,5)
                        }
                       
                        employee.Tenant.each{ tenant ->
                            if(tenant.DateFrom != "" && tenant.TenantId != null){
                                'WorkAgreementJobInformation'{
                                'ValidityPeriod'{
                                    // def oHiredDate = LocalDate.parse(org.StartDate, DateTimeFormatter.ofPattern('dd.MM.yyyy'))
                                    'StartDate'(tenant.DateFrom)
                                    if(tenant.DateTo == null || tenant.DateTo == ""){
                                    // def oEndDate = LocalDate.parse(org.TerminationDate, DateTimeFormatter.ofPattern('dd.MM.yyyy'))
                                    'EndDate'("9999-12-31")
                                    }else{
                                    'EndDate'(tenant.DateTo)
                                    }
                                }
                                if(tenant.DateTo == null || tenant.DateTo == ""){
                                    'WorkAgreementStatus'("1")
                                     
                        
                                    // def oWorkingDayList = [employee.hoursMon.replace (":", "."),employee.hoursTue.replace (":", "."),employee.hoursWed.replace (":", "."),employee.hoursThu.replace (":", "."),employee.hoursFri.replace (":", ".")].toArray()
                                    
                                    
                                def vTotalWorkingDays = 0
                                def vTotalWeeklyHours = 0
                                def vSizeCounter = 5
                                if( worktimeArray.size() <= 5){
                                    vSizeCounter = worktimeArray.size();
                                }
                                for(def i = 0; i< vSizeCounter; i++){
                                  
                                    def vWorkingDay = Float.parseFloat(worktimeArray.get(i))
                                    if(vWorkingDay > 0){
                                        vTotalWorkingDays += 1
                                    }
                                    vTotalWeeklyHours += vWorkingDay
                                }
 
                                'WorkingTimePercentage'(df.format(vTotalWeeklyHours / 0.4))
                                'WeeklyWorkingHours'(df.format(vTotalWeeklyHours))
                                'WeeklyWorkDays'(df.format(vTotalWorkingDays))
                                }else{
                                    'WorkAgreementStatus'("0")
                                }
                                'CompanyCode'(tenant.TenantId)
                                'CostCenter'(employee.CostCenter)
                                if(manager != null && manager.EmployeeId != employee.Id){
                                    'ManagerCompanyCode'(manager.Tenant.find{ return it.DateTo == null}.TenantId)
                                    'ManagerPersonWorkAgreementUUID'(manager.Id)
                                    'ManagerPersonWorkAgreementExternalID'(manager.Id)
                                }
                            }
                            }
                        }
                        
                        }
                        }
                }
                
        }
    }
            
    message.setBody(vWriter.toString())
    return message;
}

def Message CheckProcessingStatusCode(Message message){
     Reader oReader = message.getBody(Reader)
     def oRoot = new XmlSlurper().parse(oReader)
     def failedMessage = "01"
     
    def oList = oRoot.WorkforcePersonMasterDataReplResponse.findAll{
       return it.ProcessingStatusCode.text() != "01"
         
     }
     if(oList.size() != 0){
         failedMessage = "02"
         message.setBody(oList);
     }
     
     message.setProperty("MessageStatus", failedMessage)
     return message;
}